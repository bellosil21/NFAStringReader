Program Name: NFA String Reader
Authors: Dylan Pascua and Paul Patrick Bellosillo
Purpose: This program is used in order to see if a String will be accepted by a given NFA that User has inputted
Usage: Using command propmt, locate the Main.java file in the NFAStringReader folder.
	Afterwards, compile and run the file with the desired with the File in the "Test Cases" as an argument.
	Once NFA has been created, type a String to test if the NFA accepts the String. 
	Once done with testing, type "end" to exit the program.
